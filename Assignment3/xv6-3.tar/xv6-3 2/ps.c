#include "types.h"
#include "stat.h"
#include "user.h"
#include "pstat.h"

int
main(int argc, char **argv)
{
  
  
  if(argc >= 3){
    printf(2, "usage: takes -r flag or none\n");
    exit();
  }

  if(argc == 1){
      struct pstat ps;
      getpinfo(&ps);
      printf(1, "PID TICKETS TICKS\n");
      int i;
      for(i =0; i<NPROC; i++){
         if(ps.inuse[i]==1){
             printf(1, "%d %d %d\n", ps.pid[i], ps.tickets[i], ps.ticks[i]);
         } 
      }
      exit();

  }

  if(argc == 2){
      int flag = strcmp(argv[1], "-r");
      if(!flag){
          while(1){
            struct pstat ps;
            getpinfo(&ps);
            printf(1, "PID TICKETS TICKS\n");
            int i;
            for(i =0; i<NPROC; i++){
                if(ps.inuse[i]==1){
                    printf(1, "%d %d %d\n", ps.pid[i], ps.tickets[i], ps.ticks[i]);
                } 
            }
            sleep(100);
          }
      }
      else{
        printf(2, "usage: takes -r flag or none\n");
        exit();
      }
  }
  exit();
}