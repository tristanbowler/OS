#include "types.h"
#include "stat.h"
#include "user.h"

//Written by Tristan Bowler for CS5460 at the U of U 

int
main(int argc, char *argv[])
{
  
    int freeMem = freemem(); 
    printf(1, "%d\n",  freeMem);
  exit();
}
